﻿# Chris Titus Tech's Windows Utility - Install Programs, Tweaks, Fixes, and Updates
irm christitus.com/win | iex